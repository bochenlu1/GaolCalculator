# DEI-Calculator

A simple mock up of the shiney app has been uploaded, feel free to fork it or commit to main.

To work with the file locally, download it and open the .py file in R studio. There should be a button in R Studio at the top named 'Run App'. Clicking this button should run the app locally and open it in a browser running in a port. You may need to open a new terminal window and then click 'Run App' if it does not work the first time.
If when you try to use 'Run App' you get an error that says 'shiney not recognized as an internal or external command' (this might be windows specific) this ariticle can help troubleshoot: https://helpdeskgeek.com/how-to/fix-not-recognized-as-an-internal-or-external-command/. I needed to add my folder as a new environmental variable in order for it to work.
